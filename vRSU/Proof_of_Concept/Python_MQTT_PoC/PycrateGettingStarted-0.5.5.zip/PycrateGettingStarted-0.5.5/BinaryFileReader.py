import socket
import sys
from pycrate_asn1dir import J2735
import json
from binascii import unhexlify, hexlify

with open('aa.uper', 'rb') as f:
    hexdata = hexlify(f.read())

print(hexdata)