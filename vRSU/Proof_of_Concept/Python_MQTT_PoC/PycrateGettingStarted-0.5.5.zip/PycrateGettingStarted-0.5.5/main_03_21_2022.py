import socket
import sys
from pycrate_asn1dir import J2735
import json
import binascii
messageFrame_var = J2735.DSRC.MessageFrame

# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#sock.setsockopt(socket.SOL_SOCKET,socket.SO_NO_CHECK,1)

# Bind the socket to the port
ip = ""
# Listening on all interfaces
server_address = (ip, 12345)
# Listening on port number 12345

print('starting up on %s port %s' % server_address)

sock.bind(server_address)
print("Socket: "+str(sock.getsockname()))

while True:
    print('\nwaiting to receive message')
    data, address = sock.recvfrom(4096)

    print('received %s bytes from %s' % (len(data), address))
    # print('Received Raw Data:')
    # print(data)

    if data:
        try:
            messageFrame_var.from_uper(data)
            pass
        except:
            print("Received packet ASN Decode Failed...", sys.exc_info()[0], "occurred.")
            pass
        else:
            messageFrame_json = json.loads(messageFrame_var.to_json())
            # print(messageFrame_json)
            if messageFrame_json["messageId"] == 20:
                parking_light = 0
                vehicle_class = 0
                for sub in messageFrame_json["value"]["partII"]:
                    if sub["partII-Id"] == 0:
                        if "lights" in sub["partII-Value"]:
                            my_hexdata = sub["partII-Value"]["lights"]
                            parking_light = (int(my_hexdata, 16) & 128 ) >> 7
                        else:
                            parking_light = 0
                    if sub["partII-Id"] == 2:
                        if "classification" in sub["partII-Value"]:
                            vehicle_class = sub["partII-Value"]["classification"]
                        else:
                            vehicle_class = 0
                print(
                    'Received BSM====> [TempID: %s, msgCnt: %s, secMark: %s, lat: %s, long: %s, speed: %s, heading: %s, vehicle_length: %s, vehicle_width: %s, parking_light_on: %s, vehicle_class: %s]' % (
                        messageFrame_json["value"]["coreData"]["id"], messageFrame_json["value"]["coreData"]["msgCnt"],
                        messageFrame_json["value"]["coreData"]["secMark"],
                        messageFrame_json["value"]["coreData"]["lat"], messageFrame_json["value"]["coreData"]["long"],
                        messageFrame_json["value"]["coreData"]["speed"],
                        messageFrame_json["value"]["coreData"]["heading"],
                        messageFrame_json["value"]["coreData"]["size"]["length"],
                        messageFrame_json["value"]["coreData"]["size"]["width"],
                        parking_light,
                        vehicle_class))
            else:
                print('Received packet is not BSM')
