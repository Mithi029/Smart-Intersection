import socket
import sys
# Import Python Class J2735 (Python Class J2735 is output of compiling SAE J2735 .asn file)
from pycrate_asn1dir import J2735
import json
import binascii

# Create an instance of MessageFrame from J2735 Python Class
messageFrame_var = J2735.DSRC.MessageFrame
snapshot_var = J2735.DSRC.Snapshot

# Create a Python Data Dictionary in the format of J2735 Message Frame for PSM Message
# Filling random data for example below
psm_dict = {'messageId': 32, 'value': ('PersonalSafetyMessage', {'basicType': 'aPEDESTRIAN', 'secMark': 925, 'msgCnt': 15, 'id': b'\x00\x00\x00e', 'position': {'lat': 424779580, 'long': -834508520}, 'accuracy': {'semiMajor': 0, 'semiMinor': 0, 'orientation': 0}, 'speed': 1000, 'heading': 3930})}
snapshot_dict = {'thePosition':
                     {'utcTime':
                          {'year': 2022,
                           'month': 1,
                           'day': 1,
                           'hour': 1,
                           'minute': 1,
                           'second': 1,
                           'offset': 1
                           },
                      'long': 1,
                      'lat': 2,
                      'elevation': 3,
                      'heading': 4,
                      'speed':
                          {'transmisson': 'neutral',
                           'speed': 5
                          },
                      'posAccuracy':
                          {'semiMajor': 44,
                           'semiMinor': 44,
                           'orientation': 44
                          },
                      'timeConfidence': 'unavailable',
                      'posConfidence':
                          {'pos': 'unavailable',
                           'elevation': 'unavailable'
                          },
                      'speedConfidence':
                          {'heading': 'unavailable',
                           'speed': 'unavailable',
                           'throttle': 'unavailable'
                          }
                      }
                 }
# Print the python Dictionary on screen for Validation
print(psm_dict)
print(snapshot_dict)
# Assign the Python Data Dictionary to instance of Message Frame Created using set_val()
messageFrame_var.set_val(psm_dict)
snapshot_var.set_val(snapshot_dict)
# Use to_uper to encode the instance of Message Frame to Bytes and print
print(binascii.hexlify(messageFrame_var.to_uper()))
print(binascii.hexlify(snapshot_var.to_uper()))


