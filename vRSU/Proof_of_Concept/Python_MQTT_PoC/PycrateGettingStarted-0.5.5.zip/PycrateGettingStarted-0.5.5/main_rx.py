import socket
import sys
from pycrate_asn1dir import J2735
import json
messageFrame_var = J2735.DSRC.MessageFrame

# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#sock.setsockopt(socket.SOL_SOCKET,socket.SO_NO_CHECK,1)

# Bind the socket to the port
ip = ""
# Listening on all interfaces
server_address = (ip, 44444)
# Listening on port number 55555

print('starting up on %s port %s' % server_address)

sock.bind(server_address)
print("Socket: "+str(sock.getsockname()))

while True:
    print('\nwaiting to receive message')
    data, address = sock.recvfrom(4096)

    print('received %s bytes from %s' % (len(data), address))
    # print('Received Raw Data:')
    # print(data)

    if data:
        try:
            messageFrame_var.from_uper(data)
            pass
        except:
            print("Received packet ASN Decode Failed...", sys.exc_info()[0], "occurred.")
            pass
        else:
            messageFrame_json = json.loads(messageFrame_var.to_json())
            # print(messageFrame_json)
            if messageFrame_json["messageId"] == 20:
                print(
                    'Received BSM====> [TempID: %s, msgCnt: %s, secMark: %s, lat: %s, long: %s, speed: %s, heading: %s, vehicle_length: %s, vehicle_width: %s]' % (
                        messageFrame_json["value"]["coreData"]["id"], messageFrame_json["value"]["coreData"]["msgCnt"],
                        messageFrame_json["value"]["coreData"]["secMark"],
                        messageFrame_json["value"]["coreData"]["lat"], messageFrame_json["value"]["coreData"]["long"],
                        messageFrame_json["value"]["coreData"]["speed"],
                        messageFrame_json["value"]["coreData"]["heading"],
                        messageFrame_json["value"]["coreData"]["size"]["length"],
                        messageFrame_json["value"]["coreData"]["size"]["width"]))
            else:
                print('Received packet is not BSM')
